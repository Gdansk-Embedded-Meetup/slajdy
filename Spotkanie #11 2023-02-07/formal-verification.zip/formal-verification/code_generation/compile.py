import os
import sys


# dzn code examples/hello.dzn
# dzn code --model=hello_world examples/hello.dzn
# g++ -O main -I runtime/c++ hello.cc main.cc runtime/c++/runtime.cc runtime/c++/pump.cc -lpthread


idirs = ["runtime/c++",
         "runtime/c++/runtime.cc",
         "runtime/c++/pump.cc"]


def get_srcs():
    srcs = []
    files = os.listdir(os.getcwd())
    for file in files:
        if file.endswith(".cc") or file.endswith(".cpp"):
            srcs.append(file)
    return srcs


def get_compile_cmd():
    """
    Creates
    :return:
    """
    cmd = "g++ -I"
    srcs = get_srcs()
    for dir in idirs:
        cmd = cmd + f" {dir}"
    for src in srcs:
        cmd = cmd + f" {src}"
    
    # cmd = cmd + " -o main.exe"
    cmd = cmd + " -lpthread"
    return cmd


# compile_cmd = get_compile_cmd()
# print("dupa")

if __name__ == "__main__":
    compile_cmd = get_compile_cmd()
    if os.system(compile_cmd):
        raise RuntimeError(f"{compile_cmd} failed!")

    print(f"Successfully compiled code!")
    os.system("ls")
