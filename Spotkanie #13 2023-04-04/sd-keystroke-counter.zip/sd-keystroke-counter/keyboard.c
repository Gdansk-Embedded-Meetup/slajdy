#include <systemd/sd-event.h>
#include <systemd/sd-journal.h>

#include <fcntl.h>
#include <linux/input.h>
#include <unistd.h>

typedef struct input_event input_event_t;

static int handle_key_event( sd_event_source * s, int fd, uint32_t revents, void * userdata ) {
    static int keystrokes_count = 0;

    input_event_t keyboard_input;
    while ( read( fd, &keyboard_input, sizeof( input_event_t ) ) > 0 ) {
        if ( keyboard_input.type == EV_KEY && keyboard_input.value == 0 ) {
            keystrokes_count++;

            sd_journal_print( LOG_NOTICE, "Pressed keys %d times since system start.\n",
                              keystrokes_count );
        }
    }
    return 0;
}

void setup_keyboard( sd_event * event ) {
    int const keyboard_fd = open( "/dev/input/event2", O_RDONLY | O_NONBLOCK );
    sd_event_add_io( event, NULL, keyboard_fd, EPOLLIN, handle_key_event, NULL );
}
