#include <systemd/sd-daemon.h>
#include <systemd/sd-event.h>
#include <systemd/sd-journal.h>

#include <stdbool.h>

void setup_keyboard( sd_event * event );

int main() {
    sd_journal_print( LOG_INFO, "Initializing keystroke counter\n" );
    sd_event * event;
    sd_event_default( &event );

    sd_journal_print( LOG_INFO, "Setting up watchdog\n" );
    sd_event_set_watchdog( event, true );

    sd_journal_print( LOG_INFO, "Setting up keyboard\n" );
    setup_keyboard( event );

    sd_notify( 0, "READY=1" );
    sd_journal_print( LOG_INFO, "Keystroke counter ready!\n" );

    sd_event_loop( event );
}
